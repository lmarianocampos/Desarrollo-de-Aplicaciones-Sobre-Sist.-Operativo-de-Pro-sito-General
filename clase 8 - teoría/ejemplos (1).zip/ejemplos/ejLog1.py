import logging

#logging.basicConfig(level=logging.WARNING) # cambio el nivel
logging.basicConfig(level=logging.DEBUG) # cambio el nivel

logging.warning('Watch out!')  # will print a message to the console
logging.info('I told you so')  # will not print anything






