int bib_calcularSuma(int a,int b);


