

int bib_calcularSuma(int a,int b)
{
	return a+b;
}


