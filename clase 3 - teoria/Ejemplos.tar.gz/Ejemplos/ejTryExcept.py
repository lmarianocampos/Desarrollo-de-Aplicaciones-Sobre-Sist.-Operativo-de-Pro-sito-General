
try:
	n = int(input("ingrese numero:"))
	print(n)
	exit()
except Exception as e:
	print("error")

