#include <stdio.h>


int main(void)
{
	printf("<h2>Hola mundo desde C</h2>");
	return 0;
}
