python3 -m http.server --bind localhost --cgi 8001
